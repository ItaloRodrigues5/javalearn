public enum TipoLivro {
    FICCAO, NAO_FICCAO, BIOGRAFIA, TECNICO
}
