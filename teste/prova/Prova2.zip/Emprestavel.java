public interface Emprestavel {
    
    public void emprestar();
}
